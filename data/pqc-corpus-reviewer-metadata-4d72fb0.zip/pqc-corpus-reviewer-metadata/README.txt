PQC-Corpus patch-free reviewer metadata — separate derivative

Source snapshot: 4d72fb06f0a9bcbf4d03412557255ea103e3109c
Source: https://huggingface.co/datasets/pqc-datasets/pqc-corpus

commits_metadata/ and commits_filtered_metadata/ preserve every original commit field except patch_content. Messages, paths/change statistics, author fields, timestamps, repository-qualified keys, PR links and eligibility flags remain. The original release is unchanged. Repository, issue, filtered-issue and PR files are byte-identical copies.

_patch.encoding repeats patch_encoding. _patch.bytes and _patch.sha256 describe the original Git patch bytes (base64-decoded when patch_encoding=base64). json_string_content_bytes counts the source JSON-escaped string bytes excluding quotes. _source identifies the frozen source shard, one-based line, zero-based byte offset, full record byte length including its newline when present, and SHA-256 of that exact source record.

No remaining original field is silently discarded. Descriptors are additions to the derivative, not claims of new source data. Patches can be retrieved from the source snapshot using _source; this derivative cannot supply patch text by itself. Its metadata schemas replace only the source commit patch field with the two descriptor objects.

All source data shard hashes/sizes and commit row counts were checked while exporting. SHA256SUMS covers every file in this derivative except itself and COMPLETE.json. Only COMPLETE.json signals successful finalization; it is written atomically after files and checksums are durable and records their hashes. The exporter uses bounded chunks and fails above 64 MiB of metadata in one record; patch length does not determine memory usage. Some metadata records can still be large because changed_files is preserved.

Full/filtered configurations overlap. Empty PR-link arrays do not establish a direct push. Raw names, messages and discussion bodies remain, so this is not an anonymized dataset. Source licensing remains applicable; upstream code/content retains its upstream licenses.
